- Application ✔️
    - Header ✔️
        - Navigation ✔️
        - User Profile ✔️
    - Container
        - Columns
            - Left
            - Right
            - Center
            - Content
                - Carousel
                - Listing
                - Checkout
                - Cart
                - Product Listing
                - Blog
    - Footer
        - Copyright
        - Navigation
        - Contact Info

#### Event Binding 
`(eventname)="handler($event)" `

#### Property Binding 
`[propertyname]="property"`

#### Two Way Binding 
`[(ngModel)]="property"`