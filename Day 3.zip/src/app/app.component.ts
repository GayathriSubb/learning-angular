import { Component } from '@angular/core';

@Component({
  selector: 'edureka-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'edureka-session';

  userprofiles = [
    {
      "_id": "609b8d72146ee10fd0e5c5dc",
      "index": 0,
      "guid": "2e1623b2-96f0-45f6-92e5-9f3586fa538d",
      "isActive": false,
      "balance": "$1,984.73",
      "picture": "http://placehold.it/32x32",
      "age": 21,
      "eyeColor": "blue",
      "name": "Stout Glover",
      "gender": "male",
      "company": "ENDIPIN",
      "email": "stoutglover@endipin.com",
      "phone": "+1 (835) 484-3925",
      "address": "794 Polhemus Place, Nogal, California, 5846",
      "about": "Do irure enim exercitation ea ullamco tempor exercitation ipsum in officia occaecat laborum. Pariatur ut cupidatat id id id sit laboris est laborum fugiat voluptate. Consequat qui est dolor qui aliqua dolore aute exercitation amet ex. Magna mollit deserunt nostrud ipsum laborum quis id incididunt consectetur qui do sint. Elit voluptate Lorem officia occaecat dolor enim incididunt. Nulla est sit consequat aliquip cupidatat.\r\n",
      "registered": "2014-03-16T02:26:06 -06:-30",
      "latitude": 83.942192,
      "longitude": 74.051695,
      "tags": [
        "excepteur",
        "aliqua",
        "id",
        "laboris",
        "voluptate",
        "labore",
        "irure"
      ],
      "friends": [
        {
          "id": 0,
          "name": "Odonnell Mcleod"
        },
        {
          "id": 1,
          "name": "Leslie Estes"
        },
        {
          "id": 2,
          "name": "Dale Petty"
        }
      ],
      "greeting": "Hello, Stout Glover! You have 8 unread messages.",
      "favoriteFruit": "banana"
    },
    {
      "_id": "609b8d720dc74c76ff848d52",
      "index": 1,
      "guid": "6c5a7e19-e40f-479f-b9d8-c16bcea78c67",
      "isActive": true,
      "balance": "$2,982.67",
      "picture": "http://placehold.it/32x32",
      "age": 40,
      "eyeColor": "green",
      "name": "Roy Morse",
      "gender": "male",
      "company": "COSMETEX",
      "email": "roymorse@cosmetex.com",
      "phone": "+1 (955) 512-3465",
      "address": "262 Hendrickson Place, Leming, South Carolina, 4265",
      "about": "Exercitation velit amet id aliqua excepteur nostrud veniam aute do aliqua anim. Et proident ut Lorem amet ex officia anim velit excepteur labore velit. Sunt ea nulla velit nostrud pariatur incididunt excepteur mollit mollit velit duis.\r\n",
      "registered": "2020-10-19T03:14:59 -06:-30",
      "latitude": -83.543913,
      "longitude": 105.876162,
      "tags": [
        "in",
        "eiusmod",
        "et",
        "incididunt",
        "quis",
        "consequat",
        "elit"
      ],
      "friends": [
        {
          "id": 0,
          "name": "Janelle Gordon"
        },
        {
          "id": 1,
          "name": "Peterson Owens"
        },
        {
          "id": 2,
          "name": "Sharron Tillman"
        }
      ],
      "greeting": "Hello, Roy Morse! You have 3 unread messages.",
      "favoriteFruit": "apple"
    },
    {
      "_id": "609b8d7286bb6283ae08e41c",
      "index": 2,
      "guid": "42498751-bdad-4d11-a903-a548545c0200",
      "isActive": false,
      "balance": "$2,400.61",
      "picture": "http://placehold.it/32x32",
      "age": 24,
      "eyeColor": "blue",
      "name": "Hayes Barnes",
      "gender": "male",
      "company": "ZAPPIX",
      "email": "hayesbarnes@zappix.com",
      "phone": "+1 (992) 491-3294",
      "address": "645 Ovington Court, Holtville, New Jersey, 3063",
      "about": "Excepteur consectetur aliquip duis id eiusmod cillum enim nisi do et. Quis consectetur ipsum labore est. Magna excepteur voluptate deserunt excepteur qui officia ipsum adipisicing incididunt consectetur labore ullamco et.\r\n",
      "registered": "2016-01-17T11:50:24 -06:-30",
      "latitude": 88.453943,
      "longitude": -179.883667,
      "tags": [
        "incididunt",
        "eiusmod",
        "exercitation",
        "culpa",
        "reprehenderit",
        "ut",
        "id"
      ],
      "friends": [
        {
          "id": 0,
          "name": "Leila Gonzalez"
        },
        {
          "id": 1,
          "name": "Dee Barry"
        },
        {
          "id": 2,
          "name": "Jimmie Carter"
        }
      ],
      "greeting": "Hello, Hayes Barnes! You have 7 unread messages.",
      "favoriteFruit": "strawberry"
    },
    {
      "_id": "609b8d72def53adde4e9d16a",
      "index": 3,
      "guid": "823fae48-3baa-44c6-9b00-11d696cc51be",
      "isActive": false,
      "balance": "$1,215.63",
      "picture": "http://placehold.it/32x32",
      "age": 27,
      "eyeColor": "green",
      "name": "Jeannine Dyer",
      "gender": "female",
      "company": "EGYPTO",
      "email": "jeanninedyer@egypto.com",
      "phone": "+1 (851) 416-3473",
      "address": "954 Rugby Road, Cassel, Indiana, 101",
      "about": "Ex pariatur tempor aute exercitation commodo. Consectetur incididunt pariatur ad incididunt laboris incididunt do. Proident tempor reprehenderit magna nulla ullamco eu non dolor laborum. Laboris Lorem elit id sit proident occaecat et ad excepteur. Veniam aliquip nostrud ex pariatur ad laborum officia officia cupidatat ex pariatur. Cupidatat ad do velit do duis non dolor. Anim ullamco in enim excepteur aute excepteur fugiat.\r\n",
      "registered": "2014-07-26T10:15:17 -06:-30",
      "latitude": 7.465046,
      "longitude": -31.025485,
      "tags": [
        "occaecat",
        "pariatur",
        "occaecat",
        "culpa",
        "excepteur",
        "ad",
        "et"
      ],
      "friends": [
        {
          "id": 0,
          "name": "Velma Albert"
        },
        {
          "id": 1,
          "name": "Kellie Melendez"
        },
        {
          "id": 2,
          "name": "Moon Steele"
        }
      ],
      "greeting": "Hello, Jeannine Dyer! You have 1 unread messages.",
      "favoriteFruit": "banana"
    },
    {
      "_id": "609b8d724782972bf9cbf852",
      "index": 4,
      "guid": "641800f5-dbf1-467d-864e-22b8cddbcfc4",
      "isActive": true,
      "balance": "$3,275.86",
      "picture": "http://placehold.it/32x32",
      "age": 26,
      "eyeColor": "brown",
      "name": "Cabrera Crosby",
      "gender": "male",
      "company": "UPLINX",
      "email": "cabreracrosby@uplinx.com",
      "phone": "+1 (827) 581-3309",
      "address": "983 Montague Terrace, Washington, Florida, 9773",
      "about": "Sunt nostrud dolore qui occaecat adipisicing nisi consequat amet mollit. Magna laboris ullamco do enim eiusmod incididunt elit reprehenderit. Velit voluptate adipisicing laboris ut anim veniam velit quis adipisicing veniam Lorem consectetur nisi laborum.\r\n",
      "registered": "2020-07-27T06:50:02 -06:-30",
      "latitude": 82.138616,
      "longitude": 115.972256,
      "tags": [
        "proident",
        "et",
        "sit",
        "adipisicing",
        "enim",
        "anim",
        "aliquip"
      ],
      "friends": [
        {
          "id": 0,
          "name": "Nina Cortez"
        },
        {
          "id": 1,
          "name": "Kelly Edwards"
        },
        {
          "id": 2,
          "name": "Rollins Rose"
        }
      ],
      "greeting": "Hello, Cabrera Crosby! You have 2 unread messages.",
      "favoriteFruit": "strawberry"
    },
    {
      "_id": "609b8d721fad29150f042ede",
      "index": 5,
      "guid": "462f524f-cc1c-4827-a591-9014b88a71a5",
      "isActive": false,
      "balance": "$3,146.43",
      "picture": "http://placehold.it/32x32",
      "age": 29,
      "eyeColor": "brown",
      "name": "Thomas Lara",
      "gender": "male",
      "company": "QUOTEZART",
      "email": "thomaslara@quotezart.com",
      "phone": "+1 (933) 553-3385",
      "address": "663 Turnbull Avenue, Broadlands, Oregon, 7834",
      "about": "Consectetur et consequat ea duis nulla quis commodo anim. Proident ea cupidatat officia elit sint reprehenderit laborum adipisicing non nulla id minim fugiat amet. Culpa ea duis ex enim eiusmod ea anim. Incididunt eu aute Lorem veniam labore minim sit magna magna incididunt. Et eiusmod mollit ipsum ex eiusmod. Cillum quis dolore velit do velit dolore id sit tempor. Incididunt ut ipsum sunt elit ut.\r\n",
      "registered": "2017-01-22T05:18:31 -06:-30",
      "latitude": 63.94742,
      "longitude": 159.255916,
      "tags": [
        "quis",
        "ut",
        "laborum",
        "elit",
        "ut",
        "excepteur",
        "non"
      ],
      "friends": [
        {
          "id": 0,
          "name": "Burke Greene"
        },
        {
          "id": 1,
          "name": "Frankie Robles"
        },
        {
          "id": 2,
          "name": "Jordan Porter"
        }
      ],
      "greeting": "Hello, Thomas Lara! You have 2 unread messages.",
      "favoriteFruit": "strawberry"
    },
    {
      "_id": "609b8d726e6dc8aecc12c781",
      "index": 6,
      "guid": "a143acea-b345-414d-bded-f4c6d64ed0b3",
      "isActive": true,
      "balance": "$3,646.07",
      "picture": "http://placehold.it/32x32",
      "age": 24,
      "eyeColor": "blue",
      "name": "Alexander Beach",
      "gender": "male",
      "company": "GUSHKOOL",
      "email": "alexanderbeach@gushkool.com",
      "phone": "+1 (809) 467-3375",
      "address": "984 Cypress Avenue, Fedora, Minnesota, 9748",
      "about": "Elit labore ea veniam esse anim ex esse ut dolor ea. Ad ad elit deserunt est mollit culpa enim nulla ad veniam duis ex culpa labore. Ipsum ullamco sint veniam ullamco ex velit labore deserunt.\r\n",
      "registered": "2020-04-14T11:34:51 -06:-30",
      "latitude": -11.92891,
      "longitude": -139.974982,
      "tags": [
        "consequat",
        "Lorem",
        "est",
        "sunt",
        "irure",
        "deserunt",
        "adipisicing"
      ],
      "friends": [
        {
          "id": 0,
          "name": "Selena Bradley"
        },
        {
          "id": 1,
          "name": "Hill Spencer"
        },
        {
          "id": 2,
          "name": "Morgan Maddox"
        }
      ],
      "greeting": "Hello, Alexander Beach! You have 10 unread messages.",
      "favoriteFruit": "banana"
    }
  ]
}
